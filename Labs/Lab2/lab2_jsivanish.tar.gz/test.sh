python3 lab2.py google.com
python3 lab2.py nasa.gov
python3 lab2.py ewu.edu
